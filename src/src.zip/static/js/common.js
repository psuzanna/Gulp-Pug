$(document).ready(function () {
    // alert(1);
});
